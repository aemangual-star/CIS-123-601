/*
        notes
        notes
    notes


    object.method(paramater);

*/
/*pop up*/
window.alert("Enter If you dare");

/* write a message on the screen in <body>*/

document.write("Contact Us");

/* process the order by which it was coded */


//console.log("hello, programmer");

/* to continue comment you can use*/
// to continue the comment

